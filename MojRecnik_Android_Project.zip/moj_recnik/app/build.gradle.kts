plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "ru.mojrecnik.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "ru.mojrecnik.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 3
        versionName = "1.2"
    }
}
