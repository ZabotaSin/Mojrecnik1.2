package ru.mojrecnik.app

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import java.io.BufferedReader
import java.io.InputStreamReader
import android.graphics.Typeface
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.text.Editable
import android.text.TextWatcher
import org.json.JSONArray
import org.json.JSONObject

private data class Word(val id: Long, val sr: String, val latin: String, val ru: String, val example: String, val category: String = "Общее")

class MainActivity : Activity() {
    private val bg = Color.rgb(244, 242, 236)
    private val green = Color.rgb(66, 107, 90)
    private val ink = Color.rgb(38, 46, 42)
    private val prefs by lazy { getSharedPreferences("recnik", MODE_PRIVATE) }
    private val words = mutableListOf<Word>()
    private val favorites = mutableSetOf<Long>()
    private val knownWords = mutableSetOf<Long>()
    private val categories = linkedSetOf("Общее", "Дом", "Еда", "Глаголы", "Люди", "Время", "Прилагательные")
    private var selectedCategory = "Все слова"
    private lateinit var categorySpinner: Spinner
    private lateinit var listBox: LinearLayout
    private lateinit var search: EditText
    private lateinit var count: TextView
    private var onlyFavorites = false
    private var flashcardMode = false
    private var flashcard: Word? = null
    private var answerShown = false
    private var reverseMode = false
    private var submittedAnswer = ""
    private var answerCorrect = false
    private var answerInput: EditText? = null
    private var trainingFeedback: TextView? = null
    private var multiSelectMode = false
    private val selectedWordIds = linkedSetOf<Long>()
    private var interfaceLanguage = "ru"

    private fun tr(ru: String, en: String, sr: String): String = when (interfaceLanguage) { "en" -> en; "sr" -> sr; else -> ru }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        interfaceLanguage = prefs.getString("interface_language", "ru") ?: "ru"
        loadWords()
        favorites.addAll(prefs.getStringSet("favorites", emptySet())!!.mapNotNull { it.toLongOrNull() })
        knownWords.addAll(prefs.getStringSet("known_words", emptySet())!!.mapNotNull { it.toLongOrNull() })
        categories.addAll(prefs.getStringSet("categories", emptySet()) ?: emptySet())
        try {
            val assignments = JSONObject(prefs.getString("word_categories", "{}") ?: "{}")
            words.indices.forEach { i ->
                val old = words[i]
                val category = assignments.optString(old.id.toString(), old.category)
                if (category.isNotBlank()) words[i] = old.copy(category = category)
            }
        } catch (_: Exception) { }
        buildUi()
        render()
    }

    private fun loadWords() {
        val initial = listOf(
            Word(1,"здраво","zdravo","привет","Здраво! Како си? — Привет! Как ты?"),
            Word(2,"добар дан","dobar dan","добрый день","Добар дан, господине. — Добрый день, господин."),
            Word(3,"хвала","hvala","спасибо","Хвала ти! — Спасибо тебе!"),
            Word(4,"молим","molim","пожалуйста; прошу","Молим вас. — Пожалуйста / прошу вас."),
            Word(5,"да","da","да","Да, разумем. — Да, понимаю."),
            Word(6,"не","ne","нет; не","Не знам. — Не знаю."),
            Word(7,"молим те","molim te","пожалуйста (неформально)","Помози ми, молим те. — Помоги мне, пожалуйста."),
            Word(8,"извини","izvini","извини","Извини, касним. — Извини, я опаздываю."),
            Word(9,"како","kako","как","Како се зовеш? — Как тебя зовут?"),
            Word(10,"шта","šta","что","Шта је ово? — Что это?"),
            Word(11,"ко","ko","кто","Ко је то? — Кто это?"),
            Word(12,"где","gde","где","Где живиш? — Где ты живёшь?"),
            Word(13,"овде","ovde","здесь","Ја сам овде. — Я здесь."),
            Word(14,"тамо","tamo","там","Мачка је тамо. — Кошка там."),
            Word(15,"кућа","kuća","дом; домик","Моја кућа је мала. — Мой дом маленький."),
            Word(16,"стан","stan","квартира","Мој стан је леп. — Моя квартира красивая."),
            Word(17,"вода","voda","вода","Желим воду. — Я хочу воды."),
            Word(18,"чај","čaj","чай","Волим чај. — Я люблю чай."),
            Word(19,"храна","hrana","еда","Храна је добра. — Еда хорошая."),
            Word(20,"хлеб","hleb","хлеб","Купујем хлеб. — Я покупаю хлеб."),
            Word(21,"мачка","mačka","кошка","Моја мачка спава. — Моя кошка спит."),
            Word(22,"пас","pas","собака","Пас је мали. — Собака маленькая."),
            Word(23,"човек","čovek","человек; мужчина","Он је добар човек. — Он хороший человек."),
            Word(24,"жена","žena","женщина; жена","Та жена је овде. — Та женщина здесь."),
            Word(25,"пријатељ","prijatelj","друг","Он је мој пријатељ. — Он мой друг."),
            Word(26,"породица","porodica","семья","Моја породица је велика. — Моя семья большая."),
            Word(27,"добро","dobro","хорошо; добро","Добро сам. — У меня всё хорошо."),
            Word(28,"лепо","lepo","красиво; приятно","Лепо је време. — Хорошая погода."),
            Word(29,"мали","mali","маленький","Ово је мали град. — Это маленький город."),
            Word(30,"велики","veliki","большой","Имам велики сто. — У меня большой стол."),
            Word(31,"волети","voleti","любить","Волим српски језик. — Я люблю сербский язык."),
            Word(32,"желети","želeti","хотеть; желать","Желим чај. — Я хочу чаю."),
            Word(33,"имати","imati","иметь","Имам мачку. — У меня есть кошка."),
            Word(34,"бити","biti","быть","Ја сам учитељ. — Я учитель."),
            Word(35,"ићи","ići","идти; ехать","Идем кући. — Я иду домой."),
            Word(36,"говорити","govoriti","говорить","Говорим мало српски. — Я немного говорю по-сербски."),
            Word(37,"разумети","razumeti","понимать","Разумем те. — Я тебя понимаю."),
            Word(38,"учити","učiti","учить; изучать","Учимо српски. — Мы изучаем сербский."),
            Word(39,"данас","danas","сегодня","Данас радим. — Сегодня я работаю."),
            Word(40,"сутра","sutra","завтра","Видимо се сутра. — Увидимся завтра."),
            Word(41,"јуче","juče","вчера","Јуче сам био код куће. — Вчера я был дома."),
            Word(42,"време","vreme","время; погода","Какво је време? — Какая погода?"),
            Word(43,"дан","dan","день","Добар дан! — Добрый день!"),
            Word(44,"ноћ","noć","ночь","Лаку ноћ! — Спокойной ночи!"),
            Word(45,"млеко","mleko","молоко","Пијем млеко. — Я пью молоко."),
            Word(46,"кафа","kafa","кофе","Једну кафу, молим. — Один кофе, пожалуйста."),
            Word(47,"новац","novac","деньги","Немам новца. — У меня нет денег."),
            Word(48,"радити","raditi","работать; делать","Радим у школи. — Я работаю в школе."),
            Word(49,"школа","škola","школа","Школа је близу. — Школа рядом."),
            Word(50,"учитељ","učitelj","учитель","Ја сам учитељ историје. — Я учитель истории.")
        )
        val deleted = prefs.getStringSet("deleted_words", emptySet())?.mapNotNull { it.toLongOrNull() }?.toSet() ?: emptySet()
        words.addAll(initial.filterNot { deleted.contains(it.id) })
        val saved = prefs.getString("custom_words", "[]") ?: "[]"
        try {
            val arr = JSONArray(saved)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                words.add(Word(o.getLong("id"), o.getString("sr"), o.getString("latin"), o.getString("ru"), o.optString("example", ""), o.optString("category", "Общее")))
            }
        } catch (_: Exception) { }
        try {
            val overrides = JSONArray(prefs.getString("word_overrides", "[]") ?: "[]")
            for (i in 0 until overrides.length()) {
                val o = overrides.getJSONObject(i); val id = o.optLong("id")
                val wi = words.indexOfFirst { it.id == id }
                if (wi >= 0) words[wi] = words[wi].copy(sr=o.optString("sr", words[wi].sr), latin=o.optString("latin", words[wi].latin), ru=o.optString("ru", words[wi].ru), example=o.optString("example", words[wi].example))
            }
        } catch (_: Exception) { }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(dp(18), dp(16), dp(18), dp(12)) }
        setContentView(root)
        val brand = TextView(this).apply { text = "МОЈ РЕЧНИК"; textSize = 12f; letterSpacing = .18f; setTextColor(green); typeface = Typeface.DEFAULT_BOLD }
        root.addView(brand)
        root.addView(actionButton("🌐 ${languageLabel()}") { cycleLanguage() }, LinearLayout.LayoutParams(-1, dp(36)))
        val title = TextView(this).apply { text = tr("Сербский на каждый день", "Serbian every day", "Srpski svakog dana"); textSize = 25f; setTextColor(ink); typeface = Typeface.DEFAULT_BOLD; setPadding(0, dp(4), 0, dp(3)) }
        root.addView(title)
        count = TextView(this).apply { textSize = 13f; setTextColor(Color.DKGRAY); setPadding(0, 0, 0, dp(12)) }
        root.addView(count)
        search = EditText(this).apply { hint = tr("Найти слово или перевод…", "Search word or translation…", "Pronađi reč ili prevod…"); isSingleLine = true; textSize = 15f; setPadding(dp(12), 0, dp(12), 0); setBackgroundColor(Color.WHITE) }
        root.addView(search, LinearLayout.LayoutParams(-1, dp(48)))
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { render() }
            override fun afterTextChanged(s: Editable?) {}
        })
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(10), 0, dp(6)) }
        root.addView(actions)
        actions.addView(actionButton(tr("Все слова", "All words", "Sve reči")) { onlyFavorites = false; flashcardMode = false; render() }, LinearLayout.LayoutParams(0, dp(42), 1f))
        actions.addView(space(6), LinearLayout.LayoutParams(dp(6), 1))
        actions.addView(actionButton(tr("★ Избранное", "★ Favorites", "★ Omiljeno")) { onlyFavorites = true; flashcardMode = false; render() }, LinearLayout.LayoutParams(0, dp(42), 1f))
        actions.addView(space(6), LinearLayout.LayoutParams(dp(6), 1))
        actions.addView(actionButton(tr("＋ Добавить", "＋ Add", "＋ Dodaj")) { showAddDialog() }, LinearLayout.LayoutParams(0, dp(42), 1f))
        val categoryRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, 0, 0, dp(8)) }
        root.addView(categoryRow, LinearLayout.LayoutParams(-1, dp(48)))
        categorySpinner = Spinner(this)
        categoryRow.addView(categorySpinner, LinearLayout.LayoutParams(0, dp(44), 1f))
        categoryRow.addView(space(6), LinearLayout.LayoutParams(dp(6), 1))
        categoryRow.addView(actionButton(tr("＋ Папка", "＋ Folder", "＋ Fascikla")) { showAddCategoryDialog() }, LinearLayout.LayoutParams(dp(100), dp(42)))
        refreshCategorySpinner()
        categorySpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val choice = categoryOptions().getOrNull(position) ?: "Все слова"
                if (selectedCategory != choice) { selectedCategory = choice; render() }
            }
        }
        val fileActions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 0, 0, dp(8)) }
        root.addView(fileActions, LinearLayout.LayoutParams(-1, dp(42)))
        fileActions.addView(actionButton(tr("Импорт из Excel / CSV", "Import Excel / CSV", "Uvezi Excel / CSV")) { pickCsvFile() }, LinearLayout.LayoutParams(0, dp(42), 1f))
        fileActions.addView(space(6), LinearLayout.LayoutParams(dp(6), 1))
        fileActions.addView(actionButton(tr("Скачать шаблон", "Download template", "Preuzmi šablon")) { createCsvTemplate() }, LinearLayout.LayoutParams(0, dp(42), 1f))
        root.addView(actionButton(tr("⇩ Экспорт словаря и прогресса", "⇩ Export dictionary & progress", "⇩ Izvezi rečnik i napredak")) { exportDictionary() }, LinearLayout.LayoutParams(-1, dp(42)))
        val trainingActions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        trainingActions.addView(actionButton(tr("Перевод → сербский", "Translation → Serbian", "Prevod → srpski")) { showFlashcard(true) }, LinearLayout.LayoutParams(0, dp(42), 1f))
        trainingActions.addView(space(6), LinearLayout.LayoutParams(dp(6), 1))
        trainingActions.addView(actionButton(tr("Сербский → перевод", "Serbian → translation", "Srpski → prevod")) { showFlashcard(false) }, LinearLayout.LayoutParams(0, dp(42), 1f))
        root.addView(trainingActions, LinearLayout.LayoutParams(-1, dp(44)))
        val manageActions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        manageActions.addView(actionButton(if (multiSelectMode) tr("Отменить выбор", "Cancel", "Otkaži") else tr("Выбрать", "Select", "Izaberi")) {
            multiSelectMode = !multiSelectMode; selectedWordIds.clear(); render()
        }, LinearLayout.LayoutParams(0, dp(40), 1f))
        manageActions.addView(space(5), LinearLayout.LayoutParams(dp(5), 1))
        manageActions.addView(actionButton(tr("Переместить", "Move", "Premesti")) { moveSelectedWords() }, LinearLayout.LayoutParams(0, dp(40), 1f))
        manageActions.addView(space(5), LinearLayout.LayoutParams(dp(5), 1))
        manageActions.addView(actionButton(tr("Переименовать папку", "Rename folder", "Preimenuj fasciklu")) { renameSelectedCategory() }, LinearLayout.LayoutParams(0, dp(40), 1f))
        root.addView(manageActions, LinearLayout.LayoutParams(-1, dp(42)))
        val scroller = ScrollView(this).apply { isFillViewport = true; setPadding(0, dp(10), 0, 0) }
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroller.addView(listBox)
        root.addView(scroller, LinearLayout.LayoutParams(-1, 0, 1f))
        val footer = TextView(this).apply { text = "Офлайн · Српски / Srpski · Русский"; textSize = 11f; gravity = Gravity.CENTER; setTextColor(Color.GRAY); setPadding(0, dp(8), 0, 0) }
        root.addView(footer)
    }

    private fun actionButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label; textSize = 12f; isAllCaps = false; setTextColor(green); setBackgroundColor(Color.rgb(229, 233, 224)); setOnClickListener { action() }
    }
    private fun space(w: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(w, 1) }

    private fun render() {
        if (!::listBox.isInitialized) return
        listBox.removeAllViews()
        if (flashcardMode) { renderTraining(); return }
        val q = if (::search.isInitialized) search.text.toString().trim().lowercase() else ""
        val visible = words.filter { w ->
            (!onlyFavorites || favorites.contains(w.id)) &&
            (selectedCategory == "Все слова" || (selectedCategory == "Известные" && knownWords.contains(w.id)) || (selectedCategory != "Известные" && w.category == selectedCategory)) &&
            (q.isBlank() || listOf(w.sr, w.latin, w.ru, w.example, w.category).any { it.lowercase().contains(q) })
        }
        count.text = when (interfaceLanguage) { "en" -> "${words.size} words · ${knownWords.size} known · ${favorites.size} favorites"; "sr" -> "${words.size} reči · ${knownWords.size} poznato · ${favorites.size} omiljeno"; else -> "${words.size} слов · ${knownWords.size} знаю · ${favorites.size} в избранном" }
        if (visible.isEmpty()) {
            listBox.addView(TextView(this).apply { text = when { onlyFavorites -> "Пока нет избранных слов. Нажми ☆ у нужного слова."; selectedCategory == "Известные" -> "Здесь пока нет отмеченных известных слов."; else -> "Ничего не найдено." }; textSize = 15f; setTextColor(ink); setPadding(dp(8), dp(18), dp(8), dp(18)) })
        }
        visible.forEach { w -> listBox.addView(wordCard(w)) }
    }

    private fun wordCard(w: Word): View {
        val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(10), dp(12)); setBackgroundColor(Color.WHITE) }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        left.addView(TextView(this).apply { text = w.sr; textSize = 22f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ink) })
        left.addView(TextView(this).apply { text = w.latin; textSize = 13f; setTextColor(green) })
        top.addView(left, LinearLayout.LayoutParams(0, -2, 1f))
        if (multiSelectMode) {
            val cb = CheckBox(this).apply { isChecked = selectedWordIds.contains(w.id); setOnCheckedChangeListener { _, checked -> if (checked) selectedWordIds.add(w.id) else selectedWordIds.remove(w.id) } }
            top.addView(cb)
        }
        top.addView(TextView(this).apply { text = if (favorites.contains(w.id)) "★" else "☆"; textSize = 27f; setTextColor(green); gravity = Gravity.CENTER; setPadding(dp(10), 0, dp(6), 0); setOnClickListener { if (!favorites.add(w.id)) favorites.remove(w.id); prefs.edit().putStringSet("favorites", favorites.map { it.toString() }.toSet()).apply(); render() } })
        card.addView(top)
        card.addView(TextView(this).apply { text = w.ru; textSize = 17f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ink); setPadding(0, dp(5), 0, 0) })
        if (w.example.isNotBlank()) card.addView(TextView(this).apply { text = w.example; textSize = 13f; setTextColor(Color.DKGRAY); setPadding(0, dp(4), 0, 0) })
        val tools = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(8), 0, 0) }
        tools.addView(actionButton(if (knownWords.contains(w.id)) tr("✓ Уже знаю", "✓ Known", "✓ Znam") else tr("Это я уже знаю", "I know this", "Ovo već znam")) { toggleKnown(w) }, LinearLayout.LayoutParams(0, dp(38), 1f))
        tools.addView(space(6), LinearLayout.LayoutParams(dp(6), 1))
        tools.addView(actionButton(tr("✎ Изменить", "✎ Edit", "✎ Izmeni")) { showEditWord(w) }, LinearLayout.LayoutParams(0, dp(38), 0.8f))
        tools.addView(space(6), LinearLayout.LayoutParams(dp(6), 1))
        tools.addView(actionButton("📁 ${w.category}") { showMoveCategoryDialog(w) }, LinearLayout.LayoutParams(0, dp(38), 1f))
        card.addView(tools)
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 0, 0, dp(9)) }
        wrap.addView(card)
        return wrap
    }

    private fun persistCategories() {
        prefs.edit().putStringSet("categories", categories.toSet()).apply()
    }

    private fun categoryOptions() = listOf("Все слова", "Известные") + categories.toList()
    private fun displayCategory(value: String) = when (value) {
        "Все слова" -> tr("Все слова", "All words", "Sve reči")
        "Известные" -> tr("Известные", "Known", "Poznate")
        "Общее" -> tr("Общее", "General", "Opšte")
        "Дом" -> tr("Дом", "Home", "Dom")
        "Еда" -> tr("Еда", "Food", "Hrana")
        "Глаголы" -> tr("Глаголы", "Verbs", "Glagoli")
        "Люди" -> tr("Люди", "People", "Ljudi")
        "Время" -> tr("Время", "Time", "Vreme")
        "Прилагательные" -> tr("Прилагательные", "Adjectives", "Pridevi")
        else -> value
    }

    private fun refreshCategorySpinner() {
        if (!::categorySpinner.isInitialized) return
        val options = categoryOptions()
        categorySpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, options.map { displayCategory(it) })
        val index = options.indexOf(selectedCategory).takeIf { it >= 0 } ?: 0
        categorySpinner.setSelection(index, false)
        selectedCategory = options[index]
    }

    private fun toggleKnown(w: Word) {
        if (!knownWords.add(w.id)) knownWords.remove(w.id)
        prefs.edit().putStringSet("known_words", knownWords.map { it.toString() }.toSet()).apply()
        render()
        Toast.makeText(this, if (knownWords.contains(w.id)) tr("Отмечено как известное — в тренировку не попадёт", "Marked as known — excluded from practice", "Označeno kao poznato — neće biti u vežbi") else tr("Слово возвращено в изучение", "Word returned to practice", "Reč je vraćena u vežbu"), Toast.LENGTH_SHORT).show()
    }

    private fun showAddCategoryDialog() {
        val input = EditText(this).apply { hint = tr("Название папки, например: Путешествия", "Folder name, e.g. Travel", "Naziv fascikle, npr. Putovanja"); setPadding(dp(20), dp(8), dp(20), dp(8)); isSingleLine = true }
        AlertDialog.Builder(this).setTitle(tr("Новая категория", "New folder", "Nova fascikla")).setView(input)
            .setNegativeButton(tr("Отмена", "Cancel", "Otkaži"), null)
            .setPositiveButton(tr("Создать", "Create", "Napravi")) { _, _ ->
                val name = input.text.toString().trim()
                if (name.isBlank()) { Toast.makeText(this, tr("Введи название категории", "Enter a folder name", "Unesi naziv fascikle"), Toast.LENGTH_SHORT).show(); return@setPositiveButton }
                if (name.equals("Все слова", true) || name.equals("Известные", true)) { Toast.makeText(this, tr("Это зарезервированное название", "This name is reserved", "Ovaj naziv je rezervisan"), Toast.LENGTH_SHORT).show(); return@setPositiveButton }
                if (categories.any { it.equals(name, true) }) { Toast.makeText(this, tr("Такая категория уже есть", "This folder already exists", "Ova fascikla već postoji"), Toast.LENGTH_SHORT).show(); return@setPositiveButton }
                categories.add(name); persistCategories(); selectedCategory = name; refreshCategorySpinner(); render()
            }.show()
    }

    private fun showMoveCategoryDialog(w: Word) {
        val options = categories.toTypedArray()
        AlertDialog.Builder(this).setTitle("Папка для «${w.sr}»").setSingleChoiceItems(options, categories.indexOf(w.category).coerceAtLeast(0)) { dialog, which ->
            val updated = w.copy(category = options[which])
            val index = words.indexOfFirst { it.id == w.id }
            if (index >= 0) words[index] = updated
            saveCustomWords()
            // Keep categories and known/favorite state for built-in words too.
            val assignments = JSONObject()
            words.filter { it.category != "Общее" }.forEach { assignments.put(it.id.toString(), it.category) }
            prefs.edit().putString("word_categories", assignments.toString()).apply()
            dialog.dismiss(); render()
        }.setNegativeButton(tr("Отмена", "Cancel", "Otkaži"), null).show()
    }

    private fun renameSelectedCategory() {
        val old = selectedCategory
        if (old == "Все слова" || old == "Известные") { Toast.makeText(this, tr("Выбери конкретную папку", "Choose a specific folder", "Izaberi konkretnu fasciklu"), Toast.LENGTH_SHORT).show(); return }
        val input = EditText(this).apply { setText(old); isSingleLine = true }
        AlertDialog.Builder(this).setTitle(tr("Переименовать папку", "Rename folder", "Preimenuj fasciklu")).setView(input)
            .setNegativeButton(tr("Отмена", "Cancel", "Otkaži"), null)
            .setPositiveButton(tr("Сохранить", "Save", "Sačuvaj")) { _, _ ->
                val name = input.text.toString().trim()
                if (name.isBlank() || name == "Все слова" || name == "Известные" || (categories.any { it.equals(name, true) && !it.equals(old, true) })) { Toast.makeText(this, tr("Название пустое или уже занято", "Name is empty or already used", "Naziv je prazan ili već postoji"), Toast.LENGTH_SHORT).show(); return@setPositiveButton }
                categories.remove(old); categories.add(name)
                words.indices.forEach { i -> if (words[i].category == old) words[i] = words[i].copy(category = name) }
                selectedCategory = name; persistCategories(); persistAssignments(); saveCustomWords(); refreshCategorySpinner(); render()
            }.show()
    }

    private fun moveSelectedWords() {
        if (selectedWordIds.isEmpty()) { Toast.makeText(this, tr("Сначала выдели карточки", "Select cards first", "Prvo izaberi kartice"), Toast.LENGTH_SHORT).show(); return }
        val options = categories.toTypedArray()
        AlertDialog.Builder(this).setTitle(tr("Переместить выбранные карточки", "Move selected cards", "Premesti izabrane kartice"))
            .setItems(options) { _, which ->
                val dest = options[which]
                words.indices.forEach { i -> if (selectedWordIds.contains(words[i].id)) words[i] = words[i].copy(category = dest) }
                selectedWordIds.clear(); multiSelectMode = false
                persistAssignments(); saveCustomWords(); render()
                Toast.makeText(this, tr("Карточки перемещены", "Cards moved", "Kartice su premeštene"), Toast.LENGTH_SHORT).show()
            }.setNegativeButton(tr("Отмена", "Cancel", "Otkaži"), null).show()
    }

    private fun persistAssignments() {
        val assignments = JSONObject()
        words.filter { it.category != "Общее" }.forEach { assignments.put(it.id.toString(), it.category) }
        prefs.edit().putString("word_categories", assignments.toString()).apply()
    }

    private fun showEditWord(w: Word) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(8), dp(18), 0) }
        fun field(value: String, hintText: String) = EditText(this).apply { setText(value); hint = hintText; isSingleLine = true; textSize = 15f }
        val sr = field(w.sr, "Сербский кириллицей"); val latin = field(w.latin, "Srpski latinicom"); val ru = field(w.ru, "Перевод"); val ex = field(w.example, "Пример")
        val cat = Spinner(this); val catOpts = categories.toList(); cat.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, catOpts); cat.setSelection(catOpts.indexOf(w.category).coerceAtLeast(0))
        listOf(sr, latin, ru, ex).forEach { box.addView(it, LinearLayout.LayoutParams(-1, dp(46))) }; box.addView(cat)
        AlertDialog.Builder(this).setTitle(tr("Редактировать карточку", "Edit card", "Izmeni karticu")).setView(box)
            .setNegativeButton(tr("Отмена", "Cancel", "Otkaži"), null)
            .setNeutralButton(tr("Удалить", "Delete", "Obriši")) { _, _ ->
                words.removeAll { it.id == w.id }; favorites.remove(w.id); knownWords.remove(w.id); selectedWordIds.remove(w.id)
                val deleted = (prefs.getStringSet("deleted_words", emptySet()) ?: emptySet()).toMutableSet(); deleted.add(w.id.toString())
                prefs.edit().putStringSet("deleted_words", deleted).putStringSet("favorites", favorites.map { it.toString() }.toSet()).putStringSet("known_words", knownWords.map { it.toString() }.toSet()).apply()
                saveCustomWords(); persistAssignments(); render()
            }
            .setPositiveButton(tr("Сохранить", "Save", "Sačuvaj")) { _, _ ->
                val a=sr.text.toString().trim(); val b=latin.text.toString().trim(); val c=ru.text.toString().trim()
                if (a.isBlank() || b.isBlank() || c.isBlank()) { Toast.makeText(this, tr("Заполни обязательные поля", "Fill required fields", "Popuni obavezna polja"), Toast.LENGTH_SHORT).show(); return@setPositiveButton }
                val i=words.indexOfFirst { it.id == w.id }; if (i>=0) words[i]=w.copy(sr=a, latin=b, ru=c, example=ex.text.toString().trim(), category=cat.selectedItem.toString())
                persistAssignments(); saveCustomWords(); render()
            }.show()
    }

    private fun languageLabel() = when(interfaceLanguage) { "en" -> "English"; "sr" -> "Српски"; else -> "Русский" }
    private fun cycleLanguage() {
        interfaceLanguage = when(interfaceLanguage) { "ru" -> "en"; "en" -> "sr"; else -> "ru" }
        prefs.edit().putString("interface_language", interfaceLanguage).apply()
        val oldSearch = if (::search.isInitialized) search.text.toString() else ""
        buildUi(); if (::search.isInitialized) search.setText(oldSearch); render()
    }

    private fun pickCsvFile() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("text/csv", "text/comma-separated-values", "application/csv", "text/plain", "application/vnd.ms-excel"))
        }
        try { startActivityForResult(intent, 4101) }
        catch (_: Exception) { Toast.makeText(this, "Не удалось открыть выбор файла", Toast.LENGTH_LONG).show() }
    }

    private fun createCsvTemplate() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/csv"
            putExtra(Intent.EXTRA_TITLE, "moj_recnik_template.csv")
        }
        try { startActivityForResult(intent, 4102) }
        catch (_: Exception) { Toast.makeText(this, "Не удалось создать файл", Toast.LENGTH_LONG).show() }
    }

    @Deprecated("Uses document picker for compatibility with older Android versions")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        when (requestCode) {
            4101 -> importCsv(uri)
            4102 -> writeCsvTemplate(uri)
            4103 -> exportDictionaryTo(uri)
        }
    }

    private fun exportDictionary() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/csv"
            putExtra(Intent.EXTRA_TITLE, "moj_recnik_backup.csv")
        }
        try { startActivityForResult(intent, 4103) }
        catch (_: Exception) { Toast.makeText(this, "Не удалось открыть сохранение файла", Toast.LENGTH_LONG).show() }
    }

    private fun csvCell(value: String): String = if (value.any { it == ';' || it == '"' || it == '\n' || it == '\r' }) "\"${value.replace("\"", "\"\"")}\"" else value

    private fun exportDictionaryTo(uri: Uri) {
        try {
            val out = StringBuilder("Сербский кириллицей;Сербский латиницей;Перевод на русский;Пример;Категория;Уже знаю;Избранное\n")
            words.forEach { w ->
                val fields = listOf(w.sr, w.latin, w.ru, w.example, w.category, knownWords.contains(w.id).toString(), favorites.contains(w.id).toString())
                out.append(fields.joinToString(";") { csvCell(it) }).append('\n')
            }
            contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { it.write(out.toString()) }
            Toast.makeText(this, tr("Словарь и прогресс сохранены в CSV", "Dictionary and progress exported to CSV", "Rečnik i napredak su izvezeni u CSV"), Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Ошибка экспорта: ${e.localizedMessage ?: "неизвестная ошибка"}", Toast.LENGTH_LONG).show()
        }
    }

    private fun writeCsvTemplate(uri: Uri) {
        val content = "Сербский кириллицей;Сербский латиницей;Перевод на русский;Пример;Категория;Уже знаю;Избранное\nздраво;zdravo;привет;Здраво! — Привет!;Общее;false;false\n"
        try {
            contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { it.write(content) }
            Toast.makeText(this, tr("Шаблон сохранён. Открой его в Excel и добавляй строки.", "Template saved. Open it in a spreadsheet and add rows.", "Šablon je sačuvan. Otvori ga u tabeli i dodaj redove."), Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Ошибка сохранения шаблона: ${e.localizedMessage ?: "неизвестная ошибка"}", Toast.LENGTH_LONG).show()
        }
    }

    private fun importCsv(uri: Uri) {
        try {
            val text = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                ?: throw IllegalStateException("Не удалось прочитать файл")
            val lines = text.removePrefix("\uFEFF").lines().filter { it.isNotBlank() }
            if (lines.isEmpty()) throw IllegalArgumentException("Файл пустой")
            val delimiter = detectDelimiter(lines.first())
            val rows = lines.map { parseCsvLine(it, delimiter) }
            val first = rows.firstOrNull().orEmpty().joinToString(" ").lowercase()
            val hasHeader = first.contains("серб") || first.contains("latin") || first.contains("перевод") || first.contains("рус") || first.contains("пример") || first.contains("category") || first.contains("категор")
            val dataRows = if (hasHeader) rows.drop(1) else rows
            var added = 0
            var skipped = 0
            var nextId = System.currentTimeMillis()
            for (row in dataRows) {
                if (row.size < 3) { skipped++; continue }
                val sr = row.getOrNull(0).orEmpty().trim()
                val latin = row.getOrNull(1).orEmpty().trim()
                val ru = row.getOrNull(2).orEmpty().trim()
                val example = row.getOrNull(3).orEmpty().trim()
                val category = row.getOrNull(4).orEmpty().trim().ifBlank { "Общее" }
                val knownFlag = row.getOrNull(5)?.trim()?.equals("true", true)
                val favoriteFlag = row.getOrNull(6)?.trim()?.equals("true", true)
                if (sr.isBlank() || latin.isBlank() || ru.isBlank()) { skipped++; continue }
                val duplicateIndex = words.indexOfFirst { it.sr.equals(sr, true) && it.ru.equals(ru, true) }
                if (duplicateIndex >= 0) {
                    val old = words[duplicateIndex]
                    words[duplicateIndex] = old.copy(category = category)
                    if (knownFlag != null) { if (knownFlag) knownWords.add(old.id) else knownWords.remove(old.id) }
                    if (favoriteFlag != null) { if (favoriteFlag) favorites.add(old.id) else favorites.remove(old.id) }
                    categories.add(category)
                    skipped++
                    continue
                }
                val imported = Word(nextId++, sr, latin, ru, example, category)
                words.add(imported)
                if (knownFlag == true) knownWords.add(imported.id)
                if (favoriteFlag == true) favorites.add(imported.id)
                categories.add(category)
                added++
            }
            persistCategories()
            saveCustomWords()
            prefs.edit().putStringSet("known_words", knownWords.map { it.toString() }.toSet())
                .putStringSet("favorites", favorites.map { it.toString() }.toSet())
                .putString("word_categories", JSONObject().apply { words.filter { it.category != "Общее" }.forEach { put(it.id.toString(), it.category) } }.toString())
                .apply()
            search.setText("")
            onlyFavorites = false
            flashcardMode = false
            render()
            AlertDialog.Builder(this).setTitle(tr("Импорт завершён", "Import complete", "Uvoz je završen"))
                .setMessage(tr("Добавлено слов: $added\nПропущено строк: $skipped\n\nПовторяющиеся слова не добавляются. Данные сохранены на телефоне.", "Words added: $added\nRows skipped: $skipped\n\nDuplicates are skipped. Data is saved on this phone.", "Dodato reči: $added\nPreskočenih redova: $skipped\n\nDuplikati se preskaču. Podaci su sačuvani na telefonu."))
                .setPositiveButton("Готово", null).show()
        } catch (e: Exception) {
            AlertDialog.Builder(this).setTitle(tr("Не удалось импортировать файл", "Could not import file", "Uvoz datoteke nije uspeo"))
                .setMessage("Используй CSV в кодировке UTF-8 с колонками: сербский кириллицей; сербский латиницей; перевод на русский; пример; категория (необязательно).\n\nПодробности: ${e.localizedMessage ?: "неизвестная ошибка"}")
                .setPositiveButton("Понятно", null).show()
        }
    }

    private fun detectDelimiter(line: String): Char {
        val semicolons = line.count { it == ';' }
        val commas = line.count { it == ',' }
        val tabs = line.count { it == '\t' }
        return when { tabs > semicolons && tabs > commas -> '\t'; semicolons > commas -> ';'; else -> ',' }
    }

    private fun parseCsvLine(line: String, delimiter: Char): List<String> {
        val result = mutableListOf<String>()
        val cell = StringBuilder()
        var quoted = false
        var i = 0
        while (i < line.length) {
            val c = line[i]
            if (c == '"') {
                if (quoted && i + 1 < line.length && line[i + 1] == '"') { cell.append('"'); i++ }
                else quoted = !quoted
            } else if (c == delimiter && !quoted) {
                result.add(cell.toString()); cell.setLength(0)
            } else cell.append(c)
            i++
        }
        result.add(cell.toString())
        return result
    }

    private fun saveCustomWords() {
        val arr = JSONArray()
        words.filter { it.id > 50 }.forEach { w ->
            arr.put(JSONObject().put("id", w.id).put("sr", w.sr).put("latin", w.latin).put("ru", w.ru).put("example", w.example).put("category", w.category))
        }
        val overrides = JSONArray()
        words.filter { it.id in 1L..50L }.forEach { w ->
            overrides.put(JSONObject().put("id", w.id).put("sr", w.sr).put("latin", w.latin).put("ru", w.ru).put("example", w.example))
        }
        prefs.edit().putString("custom_words", arr.toString()).putString("word_overrides", overrides.toString()).apply()
    }


    private fun showAddDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        fun field(hintText: String) = EditText(this).apply { hint = hintText; textSize = 15f; isSingleLine = true }
        val sr = field(tr("Сербский кириллицей *", "Serbian in Cyrillic *", "Srpski ćirilicom *")); val latin = field(tr("Srpski latinicom *", "Serbian in Latin *", "Srpski latinicom *")); val ru = field(tr("Перевод на русский *", "Translation *", "Prevod *")); val ex = field(tr("Пример (необязательно)", "Example (optional)", "Primer (opciono)"))
        listOf(sr, latin, ru, ex).forEach { box.addView(it, LinearLayout.LayoutParams(-1, dp(48))) }
        AlertDialog.Builder(this).setTitle(tr("Новое слово", "New word", "Nova reč")).setView(box)
            .setNegativeButton(tr("Отмена", "Cancel", "Otkaži"), null)
            .setPositiveButton(tr("Сохранить", "Save", "Sačuvaj")) { _, _ ->
                val s = sr.text.toString().trim(); val l = latin.text.toString().trim(); val r = ru.text.toString().trim()
                if (s.isBlank() || l.isBlank() || r.isBlank()) { Toast.makeText(this, tr("Заполни три обязательных поля", "Fill in the three required fields", "Popuni tri obavezna polja"), Toast.LENGTH_LONG).show(); return@setPositiveButton }
                val id = System.currentTimeMillis()
                val e = ex.text.toString().trim()
                words.add(0, Word(id, s, l, r, e, selectedCategory.takeIf { it != "Все слова" && it != "Известные" } ?: "Общее"))
                persistCategories()
                saveCustomWords()
                search.setText(""); onlyFavorites = false; render()
                Toast.makeText(this, tr("Слово сохранено на устройстве", "Word saved on device", "Reč je sačuvana na uređaju"), Toast.LENGTH_SHORT).show()
            }.show()
    }

    private fun showFlashcard(translationToSerbian: Boolean) {
        val pool = words.filter { !knownWords.contains(it.id) && selectedCategory != "Известные" && (!onlyFavorites || favorites.contains(it.id)) && (selectedCategory == "Все слова" || it.category == selectedCategory) }
        if (pool.isEmpty()) { Toast.makeText(this, tr("Нет новых слов в этой выборке", "No new words in this selection", "Nema novih reči u ovom izboru"), Toast.LENGTH_LONG).show(); return }
        flashcard = pool.random(); answerShown = false; submittedAnswer = ""; answerCorrect = false; reverseMode = translationToSerbian; flashcardMode = true; render()
    }

    private fun renderTraining() {
        val w = flashcard ?: run { flashcardMode = false; render(); return }
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(dp(16), dp(24), dp(16), dp(18)); setBackgroundColor(Color.WHITE) }
        panel.addView(TextView(this).apply { text = if (reverseMode) tr("Как это будет на сербском?", "How do you say this in Serbian?", "Kako se ovo kaže na srpskom?") else tr("Вспомни перевод", "Recall the translation", "Seti se prevoda"); textSize = 18f; typeface = Typeface.DEFAULT_BOLD; setTextColor(green); gravity = Gravity.CENTER; setPadding(0,0,0,dp(14)) })
        panel.addView(TextView(this).apply { text = if (reverseMode) w.ru else w.sr; textSize = 29f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ink); gravity = Gravity.CENTER; setPadding(0,dp(8),0,dp(8)) })
        if (!reverseMode) panel.addView(TextView(this).apply { text = w.latin; textSize = 16f; setTextColor(green); gravity = Gravity.CENTER })
        answerInput = if (reverseMode) EditText(this).apply { hint = tr("Введи слово по-сербски", "Type the Serbian word", "Unesi reč na srpskom"); isSingleLine = true; textSize = 18f; setPadding(dp(10),0,dp(10),0); setText(submittedAnswer); isEnabled = !answerShown } else null
        answerInput?.let { panel.addView(it, LinearLayout.LayoutParams(-1, dp(52))) }
        trainingFeedback = TextView(this).apply { text = if (answerShown) if (reverseMode) "${w.sr} (${w.latin})" else w.ru else ""; textSize = 20f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ink); gravity = Gravity.CENTER; setPadding(0,dp(14),0,dp(12)) }
        panel.addView(trainingFeedback)
        if (answerShown && reverseMode) {
            trainingFeedback?.setTextColor(if (answerCorrect) Color.rgb(28,135,68) else Color.rgb(190,45,45))
            trainingFeedback?.text = (if (answerCorrect) "✓ " else "✗ ") + w.sr + " / " + w.latin
        }
        if (!answerShown) panel.addView(actionButton(if (reverseMode) tr("Проверить ответ", "Check answer", "Proveri odgovor") else tr("Показать перевод", "Show translation", "Prikaži prevod")) {
            if (reverseMode) {
                val entered = normalizeAnswer(answerInput?.text?.toString().orEmpty())
                if (entered.isBlank()) { Toast.makeText(this, tr("Сначала введи ответ", "Enter an answer first", "Prvo unesi odgovor"), Toast.LENGTH_SHORT).show(); return@actionButton }
                submittedAnswer = entered
                answerCorrect = entered == normalizeAnswer(w.sr) || entered == normalizeAnswer(w.latin)
                answerShown = true; render()
            } else { answerShown = true; render() }
        }, LinearLayout.LayoutParams(-1, dp(44)))
        if (answerShown) {
            panel.addView(actionButton(tr("Не помню", "Didn't remember", "Ne sećam se")) { knownWords.remove(w.id); saveKnown(); nextTrainingCard() }, LinearLayout.LayoutParams(-1, dp(42)))
            panel.addView(actionButton(tr("Уже знаю", "I know this", "Već znam")) { knownWords.add(w.id); saveKnown(); nextTrainingCard() }, LinearLayout.LayoutParams(-1, dp(42)))
        }
        panel.addView(actionButton(tr("Выйти из повторения", "Exit practice", "Izađi iz vežbe")) { flashcardMode = false; flashcard = null; render() }, LinearLayout.LayoutParams(-1, dp(40)))
        listBox.addView(panel, LinearLayout.LayoutParams(-1, -2))
    }

    private fun normalizeAnswer(s: String) = s.trim().lowercase().replace(Regex("\\s+"), " ")
    private fun saveKnown() { prefs.edit().putStringSet("known_words", knownWords.map { it.toString() }.toSet()).apply() }
    private fun nextTrainingCard() { flashcardMode = false; showFlashcard(reverseMode) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
